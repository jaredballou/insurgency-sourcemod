
CREATE TABLE gaben (gaben int primary key, fat varchar(32));

INSERT INTO gaben VALUES(1, 'what the');
INSERT INTO gaben VALUES(2, 'Bee''s Knees!');
INSERT INTO gaben VALUES(3, 'newell');
INSERT INTO gaben VALUES(4, 'CRAB CAKE.');
